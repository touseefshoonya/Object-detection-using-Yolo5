# Object detection using yolo v5 > 2024-05-16 4:21pm
https://universe.roboflow.com/touseef-lk9pg/object-detection-using-yolo-v5-abv2z

Provided by a Roboflow user
License: CC BY 4.0

